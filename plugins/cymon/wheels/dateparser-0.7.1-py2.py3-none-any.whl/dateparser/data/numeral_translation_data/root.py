# -*- coding: utf-8 -*-
info = {
    "%spellout-cardinal": {
        "(0, 'inf')": "=#,##0.#=;"
    },
    "%spellout-numbering": {
        "(0, 'inf')": "=#,##0.#=;"
    },
    "%spellout-numbering-year": {
        "(0, 'inf')": "=0=;"
    },
    "%spellout-ordinal": {
        "(0, 'inf')": "=#,##0.#=.;"
    }
}