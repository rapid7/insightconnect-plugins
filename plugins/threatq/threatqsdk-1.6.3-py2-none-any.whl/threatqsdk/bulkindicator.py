import json
import datetime
from threatqsdk import exceptions
from threatqsdk.source import make_source_list
from threatqsdk.tqobject import ThreatQuotientObject


class BulkIndicator(ThreatQuotientObject):

    classes = {
        'IP Address': 'network',
        'URL': 'network',
        'FQDN': 'network',
        'MD5': 'host',
        'SHA-1': 'host',
        'SHA-256': 'host',
        'SHA-384': 'host',
        'SHA-512': 'host',
        'Email Address': 'network',
        'Filename': 'host',
        'Fuzzy Hash': 'host',
        'Mutex': 'host',
        'Registry Key': 'host',
        'User-agent': 'network',
        'CIDR Block': 'network',
        'Email Subject': 'network'
    }

    def __init__(self, tq):
        if not tq:
            raise ValueError("Must provide Threatq object")

        self.tq = tq

        self.value = None
        self.status = None
        self.attributes = []
        self.typename = None
        self.indicators = []
        self.events = []
        self.adversaries = []
        self.published_at = ""

    def set_status(self, statusname):
        """ Set the status of this indicator.
        This action is not automatically mirrored to ThreatQuotient

        :param str statusname: Human-readable status name
        """
        self.status = statusname

    def set_type(self, typename):
        """ Set the type of this indicator.
        This action is not automatically mirrored to ThreatQuotient

        :param str typename: Human-readable type name
        """
        self.typename = typename

    def set_class(self, itype):
        """ Set the class of this indicator.
        This action is not automatically mirrored to ThreatQuotient

        :param str itype: Indicator type to derive the class from
        """
        if itype not in self.classes:
            raise ValueError(str(itype) + ' is not a valid indicator type')

        self.classname = self.classes[itype]

    def set_value(self, value):
        """ Set the value of this indicator.
        This action is not automatically mirrored to ThreatQuotient
        """
        self.value = value

    def set_published_at(self, published_at):
        """ Set published_at for this indicator.
        This action is not automatically mirrored to ThreatQuotient

        :param datetime_object published_at: datetime object
        """
        self.published_at = datetime.datetime.strftime(
            published_at, "%Y-%m-%d %H:%M:%S")

    def add_attribute(self, name, value, source=None):
        """ Add an attribute key/value pair
        This action is not automatically mirrored to ThreatQuotient

        :param str name: attribute name/key
        :param str value: attribute value
        :param str source: attribute source
        """
        if source:
            self.attributes.append(
                {'name': name, 'value': value, 'sources': [{'name': source}]})
        else:
            self.attributes.append({'name': name, 'value': value})

    def to_dict(self):
        # Ensure value is set
        if not self.value:
            raise ValueError("Cannot upload without a value")
        # Ensure typename is set
        if not self.typename:
            raise ValueError("Cannot upload without a typename")
        # Ensure statusname is set
        if not self.status:
            raise ValueError("Cannot upload without a statusname")
        if self.published_at:
            self.published_at = self.validate_date(self.published_at)
        res = {}

        res['status'] = {'id': self.tq.getstatusidbyname(self.status)}
        res['value'] = self.value
        res['attributes'] = self.attributes
        res['type'] = {'name': self.typename}
        res['class'] = self.classes.get(self.typename)
        res['normalize'] = 'Y'
        res['indicators'] = self.indicators
        res['events'] = self.events
        res['adversaries'] = self.adversaries
        res['published_at'] = self.published_at

        return res

    def relate_indicator(self, value, itype):
        """ Relate the values of two indicators.
        """
        self.indicators.append({'value': value, 'type': itype})

    def relate_event(self, eid):
        """ Relate to an event

        :param int eid: Event id
        """
        self.events.append({'id': eid})

    def relate_adversary(self, aid):
        """ Relate to an adversary

        :param int aid: Adversary id
        """
        self.adversaries.append({'id': aid})

    def __str__(self):
        res = {}

        res['status'] = {'id': self.tq.getstatusidbyname(self.status)}
        res['value'] = self.value
        res['attributes'] = self.attributes
        res['type'] = {'name': self.typename}
        res['class'] = self.classes.get(self.typename)

        return json.dumps(res)

    @staticmethod
    def _get_base_endpoint_name():
        pass

    def _id(self):
        pass

    def _set_id(self, value):
        pass

    def _to_dict(self, **kwargs):
        pass

    def fill_from_api_response(self, api_response):
        pass
