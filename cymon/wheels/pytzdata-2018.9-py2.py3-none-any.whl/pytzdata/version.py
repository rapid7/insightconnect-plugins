# -*- coding: utf-8 -*-

VERSION = "2018.9"

OLSON_VERSION = "2018i"
